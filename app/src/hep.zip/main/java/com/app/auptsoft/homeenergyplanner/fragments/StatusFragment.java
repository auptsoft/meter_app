package com.app.auptsoft.homeenergyplanner.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by Andrew on 21.3.19.
 */

public class StatusFragment extends Fragment {
}
