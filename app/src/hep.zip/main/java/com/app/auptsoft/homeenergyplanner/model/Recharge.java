package com.app.auptsoft.homeenergyplanner.model;

/**
 * Created by Andrew on 21.3.19.
 */

public class Recharge {

}
