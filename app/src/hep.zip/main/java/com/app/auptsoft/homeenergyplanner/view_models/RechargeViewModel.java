package com.app.auptsoft.homeenergyplanner.view_models;

/**
 * Created by Andrew on 21.3.19.
 */

public class RechargeViewModel {
}
