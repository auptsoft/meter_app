package com.app.auptsoft.homeenergyplanner.presenters;

public class MeterFragmentPresenter {
    private boolean loading = false;

    public boolean isLoading() {
        return loading;
    }

    public void setLoading(boolean loading) {
        this.loading = loading;
    }
}
