package com.app.auptsoft.homeenergyplanner.services;

/**
 * Created by Andrew on 23.3.19.
 */

public class SendableSerivce {

}
