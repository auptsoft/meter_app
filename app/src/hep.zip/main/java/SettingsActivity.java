import android.support.v7.app.AppCompatActivity;

/**
 * Created by Andrew on 21.3.19.
 */

public class SettingsActivity extends AppCompatActivity {
}
